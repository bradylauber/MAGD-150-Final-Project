let palette;
let particles = [];
let img;

function preload() {
  img = loadImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRqB4RHjMynBNayuFnPVbE4oHCq3JM-4UETBA&s');
}

function setup() {
  createCanvas(500, 500);
  colorMode(RGB);

  palette = createPalette();

  palette
    .add(color("#0a0f2d"))
    .add(color("#3c1f5c"))
    .add(color("#5b2e91"))
    .add(color("#e6399b"))
    .add(color("#3ddbf0"));

  for (let i = 0; i < 80; i++) {
    particles.push({
      angle: random(TWO_PI),
      radius: random(50, 250),
      speed: random(0.01, 0.03),
      inward: random(0.05, 0.2),
      size: random(5, 12),
      col: palette.get(i % palette.size())
    });
  }
}

function draw() {
  background(0);

  tint(255, 150);
  image(img, 0, 0, width, height);
  noTint();

  translate(width/2, height/2);

  for (let p of particles) {
    let x = cos(p.angle) * p.radius;
    let y = sin(p.angle) * p.radius;

    fill(p.col);
    noStroke();
    ellipse(x, y, p.size);

    p.angle += p.speed;

    p.radius -= p.inward;

    if (p.radius < 10) {
      p.radius = random(180, 260);
      p.angle = random(TWO_PI);
    }
  }
}
